package br.anhembi.proj01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Proj01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
